Space to jump.

Running:
Unzip and change directory into the directory that contains Beta-Flappy-Santa.jar
	unzip flap-santa.zip
	cd flap-santa
Run the program from that directory
	java -jar Beta-Flappy-Santa.jar	
